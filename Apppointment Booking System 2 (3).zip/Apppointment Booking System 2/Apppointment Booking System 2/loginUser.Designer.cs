﻿namespace Apppointment_Booking_System_2
{
    partial class loginUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loginUser_close = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.loginUser_username = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.loginUser_password = new System.Windows.Forms.TextBox();
            this.loginUser_btn = new System.Windows.Forms.Button();
            this.loginUser_showPass = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.loginUser_registerHere = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.HomeLoginUser = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // loginUser_close
            // 
            this.loginUser_close.AutoSize = true;
            this.loginUser_close.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginUser_close.Location = new System.Drawing.Point(370, 9);
            this.loginUser_close.Name = "loginUser_close";
            this.loginUser_close.Size = new System.Drawing.Size(13, 16);
            this.loginUser_close.TabIndex = 26;
            this.loginUser_close.Text = "x";
            this.loginUser_close.Click += new System.EventHandler(this.loginUser_close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(143, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 19);
            this.label1.TabIndex = 17;
            this.label1.Text = "Welcome back!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(58, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Username:";
            // 
            // loginUser_username
            // 
            this.loginUser_username.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginUser_username.Location = new System.Drawing.Point(61, 217);
            this.loginUser_username.Multiline = true;
            this.loginUser_username.Name = "loginUser_username";
            this.loginUser_username.Size = new System.Drawing.Size(305, 30);
            this.loginUser_username.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(58, 260);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "Password:";
            // 
            // loginUser_password
            // 
            this.loginUser_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginUser_password.Location = new System.Drawing.Point(61, 279);
            this.loginUser_password.Multiline = true;
            this.loginUser_password.Name = "loginUser_password";
            this.loginUser_password.PasswordChar = '*';
            this.loginUser_password.Size = new System.Drawing.Size(305, 30);
            this.loginUser_password.TabIndex = 21;
            // 
            // loginUser_btn
            // 
            this.loginUser_btn.BackColor = System.Drawing.Color.MidnightBlue;
            this.loginUser_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginUser_btn.FlatAppearance.BorderSize = 0;
            this.loginUser_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loginUser_btn.ForeColor = System.Drawing.Color.White;
            this.loginUser_btn.Location = new System.Drawing.Point(61, 340);
            this.loginUser_btn.Name = "loginUser_btn";
            this.loginUser_btn.Size = new System.Drawing.Size(100, 35);
            this.loginUser_btn.TabIndex = 22;
            this.loginUser_btn.Text = "LOGIN";
            this.loginUser_btn.UseVisualStyleBackColor = false;
            this.loginUser_btn.Click += new System.EventHandler(this.loginUser_btn_Click);
            // 
            // loginUser_showPass
            // 
            this.loginUser_showPass.AutoSize = true;
            this.loginUser_showPass.BackColor = System.Drawing.Color.Transparent;
            this.loginUser_showPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginUser_showPass.ForeColor = System.Drawing.Color.Gray;
            this.loginUser_showPass.Location = new System.Drawing.Point(244, 315);
            this.loginUser_showPass.Name = "loginUser_showPass";
            this.loginUser_showPass.Size = new System.Drawing.Size(122, 20);
            this.loginUser_showPass.TabIndex = 23;
            this.loginUser_showPass.Text = "Show Password";
            this.loginUser_showPass.UseVisualStyleBackColor = false;
            this.loginUser_showPass.CheckedChanged += new System.EventHandler(this.loginUser_showPass_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(83, 448);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 15);
            this.label4.TabIndex = 24;
            this.label4.Text = "Don\'t have an account?";
            // 
            // loginUser_registerHere
            // 
            this.loginUser_registerHere.AutoSize = true;
            this.loginUser_registerHere.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginUser_registerHere.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginUser_registerHere.ForeColor = System.Drawing.Color.DimGray;
            this.loginUser_registerHere.Location = new System.Drawing.Point(224, 448);
            this.loginUser_registerHere.Name = "loginUser_registerHere";
            this.loginUser_registerHere.Size = new System.Drawing.Size(96, 15);
            this.loginUser_registerHere.TabIndex = 25;
            this.loginUser_registerHere.Text = "Register Here";
            this.loginUser_registerHere.Click += new System.EventHandler(this.loginUser_registerHere_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.loginUser_registerHere);
            this.panel1.Controls.Add(this.loginUser_username);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.loginUser_showPass);
            this.panel1.Controls.Add(this.loginUser_password);
            this.panel1.Controls.Add(this.loginUser_btn);
            this.panel1.Location = new System.Drawing.Point(261, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(421, 603);
            this.panel1.TabIndex = 27;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(163, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 19);
            this.label5.TabIndex = 26;
            this.label5.Text = "Login User";
            // 
            // HomeLoginUser
            // 
            this.HomeLoginUser.AutoSize = true;
            this.HomeLoginUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.HomeLoginUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeLoginUser.ForeColor = System.Drawing.Color.DimGray;
            this.HomeLoginUser.Location = new System.Drawing.Point(52, 547);
            this.HomeLoginUser.Name = "HomeLoginUser";
            this.HomeLoginUser.Size = new System.Drawing.Size(56, 20);
            this.HomeLoginUser.TabIndex = 27;
            this.HomeLoginUser.Text = "Home";
            this.HomeLoginUser.Click += new System.EventHandler(this.HomeLoginUser_Click);
            // 
            // loginUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(991, 603);
            this.Controls.Add(this.HomeLoginUser);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.loginUser_close);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "loginUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "loginUser";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label loginUser_close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox loginUser_username;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox loginUser_password;
        private System.Windows.Forms.Button loginUser_btn;
        private System.Windows.Forms.CheckBox loginUser_showPass;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label loginUser_registerHere;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label HomeLoginUser;
    }
}