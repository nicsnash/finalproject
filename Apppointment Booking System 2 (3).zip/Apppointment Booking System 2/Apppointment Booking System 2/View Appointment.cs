﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apppointment_Booking_System_2
{
    public partial class View_Appointment : Form
    {
        public View_Appointment()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblHomeViewApp_Click(object sender, EventArgs e)
        {
           Home lForm = new Home();
            lForm.Show();
            this.Hide();
        }

       
        

        private void btnUpdatePro_Click(object sender, EventArgs e)
        {

        }

        private void btneditProfile_Click(object sender, EventArgs e)
        {

        }
    }
}
