﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apppointment_Booking_System_2
{
    public partial class loginUser : Form
    {
        public loginUser()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True");
        private void loginUser_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void loginUser_registerHere_Click(object sender, EventArgs e)
        {
            signup sForm = new signup();
            sForm.Show();
            this.Hide();
        }

        private void loginUser_btn_Click(object sender, EventArgs e)
        {
            if (loginUser_username.Text == "" || loginUser_password.Text == "")
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    conn.Open();

                    string username = loginUser_username.Text.Trim();
                    string password = loginUser_password.Text.Trim();

                    string selectData = "SELECT * FROM signup_data WHERE username = @username AND password = @password";
                    using (SqlCommand cmd = new SqlCommand(selectData, conn))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        if (table.Rows.Count >= 1)
                        {
                            MessageBox.Show("Logged In successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Get the user's email from the datatable
                            string userEmail = table.Rows[0]["email"].ToString();

                            // Check if the user has completed their profile information
                            bool isProfileComplete = IsProfileComplete(userEmail, conn);

                            if (isProfileComplete)
                            {
                                // If profile is complete, open the patient info create form
                                patient_info_create pInfoForm = new patient_info_create(userEmail);
                                pInfoForm.Show();
                            }
                            else
                            {
                                // If profile is not complete, open the book appointment form
                                patientAppointment lForm = new patientAppointment();
                                lForm.Show();
                            }

                            // Hide the current login form
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect Username/Password", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error Connecting: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }
            }
        }


        private bool IsProfileComplete(string userEmail, SqlConnection connection)
        {
            try
            {
                // Open the connection if it's not already open
                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }

                string query = "SELECT COUNT(*) FROM datapatient WHERE Email = @userEmail";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@userEmail", userEmail);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking profile completeness: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                // Close the connection if it was opened in this method
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }






        private void HomeLoginUser_Click(object sender, EventArgs e)
        {
            Home lForm = new Home();
            lForm.Show();
            this.Hide();
        }

        private void loginUser_showPass_CheckedChanged(object sender, EventArgs e)
        {
            // Check if the show password checkbox is checked
            if (loginUser_showPass.Checked)
            {
                // If checked, show the password characters
                loginUser_password.UseSystemPasswordChar = true;
            }
            else
            {
                // If not checked, hide the password characters
                loginUser_password.UseSystemPasswordChar = false;
            }
        }
    }

   
    }

