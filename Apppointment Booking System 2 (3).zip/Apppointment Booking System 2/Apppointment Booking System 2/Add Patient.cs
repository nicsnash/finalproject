﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Apppointment_Booking_System_2
{
    public partial class Add_Patient : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True");
        public Add_Patient()
        {
            InitializeComponent();
           
        }
        private void Form_Load(object sender, EventArgs e)
        {
            LoadPatientData();
        }
        private string GenerateICNumber()
        {
            // You can implement your logic here to generate the IC Number
            // For simplicity, let's assume it's a random 5-digit number
            Random rnd = new Random();
            return "IC" + rnd.Next(10000, 99999).ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string lastName = txtLastname.Text;
            DateTime dob = dateTimePicker1.Value;
            string contact = txtContact.Text;
            string maritalStatus = comboBox2.Text;
            string gender = comboBox1.Text;
            string address = txtAddress.Text;
            string email = txtEmail.Text;

            // Check if any required field is empty
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(lastName) || string.IsNullOrWhiteSpace(contact) || string.IsNullOrWhiteSpace(address) || string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Please fill up all the information fields.", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the method
            }
            // Validate contact number
            if (!contact.StartsWith("09") || contact.Length != 11 || !contact.Skip(2).All(char.IsDigit))
            {
                MessageBox.Show("Please enter a valid mobile number starting with '09' and with 11 digits.", "Invalid Contact Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the method
            }
            // Validate email address
            if (!email.EndsWith("@gmail.com"))
            {
                MessageBox.Show("Please enter a valid Gmail address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the method
            }
            // Check if marital status is selected
            if (string.IsNullOrEmpty(maritalStatus))
            {
                MessageBox.Show("Please select your marital status.", "Marital Status Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the method
            }

            // Check if gender is selected
            if (string.IsNullOrEmpty(gender))
            {
                MessageBox.Show("Please select your gender.", "Gender Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the method
            }

            try
            {
                connect.Open();
                string query = "INSERT INTO datapatient ([IC Number], [First Name], [Last Name], [Date of Birth], [Marital Status], [Gender], [Address], [Contact No], [Email]) VALUES (@ICNumber, @FirstName, @LastName, @DOB, @MaritalStatus, @Gender, @Address, @ContactNo, @Email)";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@ICNumber", GenerateICNumber());
                cmd.Parameters.AddWithValue("@FirstName", name);
                cmd.Parameters.AddWithValue("@LastName", lastName);
                cmd.Parameters.AddWithValue("@DOB", dob);
                cmd.Parameters.AddWithValue("@MaritalStatus", maritalStatus);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@ContactNo", contact);
                cmd.Parameters.AddWithValue("@Email", email);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Patient added successfully!");
                    // Reload patient data and update DataGridView
                    LoadPatientData();
                }
                else
                {
                    MessageBox.Show("Failed to add patient!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connect.State != ConnectionState.Closed)
                {
                    connect.Close();
                }
            }
        }

        public void LoadPatientData()
        {

            try
            {
                using (SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"))
                {
                    connect.Open();
                    string query = "SELECT * FROM datapatient";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connect);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            LoadPatientData();
            // Check if a row is selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Retrieve the IC number of the selected patient
                string ICNumber = selectedRow.Cells["IC Number"].Value.ToString();

                // Ask for confirmation before updating the patient
                DialogResult result = MessageBox.Show("Are you sure you want to update this patient's information?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // Retrieve the modified data from the input fields
                    string name = txtName.Text;
                    string lastName = txtLastname.Text;
                    DateTime dob = dateTimePicker1.Value;
                    string contact = txtContact.Text;
                    string maritalStatus = comboBox2.Text;
                    string gender = comboBox1.Text;
                    string address = txtAddress.Text;
                    string email = txtEmail.Text;

                    try
                    {
                        connect.Open();
                        string query = "UPDATE datapatient SET [First Name] = @FirstName, [Last Name] = @LastName, [Date of Birth] = @DOB, [Marital Status] = @MaritalStatus, [Gender] = @Gender, [Address] = @Address, [Contact No] = @ContactNo, [Email] = @Email WHERE [IC Number] = @ICNumber";
                        SqlCommand cmd = new SqlCommand(query, connect);
                        cmd.Parameters.AddWithValue("@ICNumber", ICNumber);
                        cmd.Parameters.AddWithValue("@FirstName", name);
                        cmd.Parameters.AddWithValue("@LastName", lastName);
                        cmd.Parameters.AddWithValue("@DOB", dob);
                        cmd.Parameters.AddWithValue("@MaritalStatus", maritalStatus);
                        cmd.Parameters.AddWithValue("@Gender", gender);
                        cmd.Parameters.AddWithValue("@Address", address);
                        cmd.Parameters.AddWithValue("@ContactNo", contact);
                        cmd.Parameters.AddWithValue("@Email", email);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Patient updated successfully!");
                            // Reload patient data and update DataGridView
                            LoadPatientData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to update patient!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connect.State != ConnectionState.Closed)
                        {
                            connect.Close();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a patient to update.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Check if a row is clicked
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                // Populate the input fields with the data from the selected row
                txtName.Text = selectedRow.Cells["First Name"].Value.ToString();
                txtLastname.Text = selectedRow.Cells["Last Name"].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(selectedRow.Cells["Date of Birth"].Value);
                txtContact.Text = selectedRow.Cells["Contact No"].Value.ToString();
                comboBox2.Text = selectedRow.Cells["Marital Status"].Value.ToString();
                comboBox1.Text = selectedRow.Cells["Gender"].Value.ToString();
                txtAddress.Text = selectedRow.Cells["Address"].Value.ToString();
                txtEmail.Text = selectedRow.Cells["Email"].Value.ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Ask for confirmation before clearing all input fields
            DialogResult result = MessageBox.Show("Are you sure you want to clear all input fields?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Clear all input fields
                txtName.Text = "";
                txtLastname.Text = "";
                dateTimePicker1.Value = DateTime.Today;
                txtContact.Text = "";
                comboBox2.SelectedIndex = -1;
                comboBox1.SelectedIndex = -1;
                txtAddress.Text = "";
                txtEmail.Text = "";
            }
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Check if a row is selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Retrieve the IC number of the selected patient
                string ICNumber = selectedRow.Cells["IC Number"].Value.ToString();

                // Ask for confirmation before deleting the patient
                DialogResult result = MessageBox.Show("Are you sure you want to delete this patient?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        connect.Open();
                        string query = "DELETE FROM datapatient WHERE [IC Number] = @ICNumber";
                        SqlCommand cmd = new SqlCommand(query, connect);
                        cmd.Parameters.AddWithValue("@ICNumber", ICNumber);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Patient deleted successfully!");
                            // Reload patient data and update DataGridView
                            LoadPatientData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete patient!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connect.State != ConnectionState.Closed)
                        {
                            connect.Close();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a patient to delete.");
            }
        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

    
    

