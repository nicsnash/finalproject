﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apppointment_Booking_System_2
{
    public partial class Book_Appointment : Form
    {
        private patient_info_create updateProfileForm;
        private string scheduleInformation; // Ensure correct variable name
        private string scheduleInfo;
        public Book_Appointment()
        {
            InitializeComponent();
        }
      

        public Book_Appointment(patient_info_create updateProfileForm)
        {
            InitializeComponent();
            this.updateProfileForm = updateProfileForm; // Assign the provided instance of patient_info_create form to the field
        }



        public static class FileHelper
        {
            private const string FilePath = "userInfo.txt";

            public static void SaveUserInfo(string userInfo)
            {
                File.WriteAllText(FilePath, userInfo);
            }

            public static string LoadUserInfo()
            {
                if (File.Exists(FilePath))
                {
                    return File.ReadAllText(FilePath);
                }
                return string.Empty;
            }
        }
        private void LoadUserInfo()
        {
            // Load user information from file
            string userInfo = FileHelper.LoadUserInfo();
            // Display the user information in the respective fields
            // You can implement this part according to your UI design
        }

        public void SetUserInformation(string userInfo)
        {
            lblOutputpatient.Text = userInfo;
           
        }
      

        private void btnUpdatePro_Click(object sender, EventArgs e)
        {
            patient_info_create updateForm = new patient_info_create("user@example.com"); // Provide the user's email
            updateForm.Show();

        }

        private void HomepatientApp_Click(object sender, EventArgs e)
        {
            Home lForm = new Home();
            lForm.Show();
            this.Hide();
        }

        private void btnMakeA_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the text from the txtSymptom and txtComment textboxes
                string symptom = txtSymptom.Text;
                string comment = txtComment.Text;

                // Check if the symptom textbox is empty
                if (string.IsNullOrWhiteSpace(symptom))
                {
                    MessageBox.Show("Please enter symptoms.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Exit the method without saving if the symptom is empty
                }

                // Check if the comment is empty
                if (string.IsNullOrWhiteSpace(comment))
                {
                    // If the comment is empty, set a default message
                    comment = "No comment provided";
                }

                // Ask for confirmation before booking the appointment
                DialogResult result = MessageBox.Show("Are you sure you want to book this appointment?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // Save the message to the database
                    SaveMessageToDatabase(symptom, comment);

                    // Display a confirmation message
                    MessageBox.Show("Appointment successfully booked. Thank you!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // After saving the message, you can proceed with the appointment booking process
                    // For example, you can open the Book_Appointment form here
                    View_Appointment lForm = new View_Appointment();
                    lForm.Show();
                    this.Hide();
                }
                else
                {
                    // User clicked "No" - do nothing or provide appropriate feedback
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void SaveMessageToDatabase(string symptom, string comment)
        {
            // Connection string for your SQL Server database
            string connectionString = "Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL query to insert the message into the database
                string query = "INSERT INTO AppointmentData (Symptoms, Comment) VALUES (@Symptoms, @Comment)";

                // Create a SqlCommand object with the query and connection
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to the query
                    command.Parameters.AddWithValue("@Symptoms", symptom);
                    command.Parameters.AddWithValue("@Comment", comment);

                    // Open the database connection
                    connection.Open();

                    // Execute the query
                    command.ExecuteNonQuery();
                }
            }
        }

        private void SaveMessageToFile(string message)
        {
            // Define the file path where you want to save the message
            string filePath = "userMessages.txt";

            // Append the message to the file
            File.AppendAllText(filePath, message);
        }


        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       

        private void btnLogout_Click(object sender, EventArgs e)
        {
        }
      

     
        private void btnChooseImage_Click_1(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Image Files (*.jpg; *.png)|*.jpg;*.png";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    // Get the selected image file path
                    string imagePath = dialog.FileName;

                    // Load the selected image into pictureBox1
                    pictureBox1.Image = Image.FromFile(imagePath);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void btnsaveimage_Click(object sender, EventArgs e)
        {
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtSymptom_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtComment_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblSchedule_Click(object sender, EventArgs e)
        {

        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
        }
    

    

