﻿namespace Apppointment_Booking_System_2
{
    partial class patient_info_create
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.HomepatientApp = new System.Windows.Forms.Label();
            this.dtpDOBinfo = new System.Windows.Forms.DateTimePicker();
            this.comboBox1G = new System.Windows.Forms.ComboBox();
            this.comboBox1MStatus = new System.Windows.Forms.ComboBox();
            this.btnUpdateInfos = new System.Windows.Forms.Button();
            this.txtEmailInfo = new System.Windows.Forms.TextBox();
            this.txtCNOInfo = new System.Windows.Forms.TextBox();
            this.txtAddUInfo = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtFirstname = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblContactNo = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblAdd = new System.Windows.Forms.Label();
            this.lblICNumber = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblMaritalStatus = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.HomepatientApp);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1107, 53);
            this.panel1.TabIndex = 10;
            // 
            // HomepatientApp
            // 
            this.HomepatientApp.AutoSize = true;
            this.HomepatientApp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomepatientApp.Location = new System.Drawing.Point(152, 19);
            this.HomepatientApp.Name = "HomepatientApp";
            this.HomepatientApp.Size = new System.Drawing.Size(52, 20);
            this.HomepatientApp.TabIndex = 1;
            this.HomepatientApp.Text = "Home";
            // 
            // dtpDOBinfo
            // 
            this.dtpDOBinfo.CustomFormat = "";
            this.dtpDOBinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDOBinfo.Location = new System.Drawing.Point(211, 305);
            this.dtpDOBinfo.Name = "dtpDOBinfo";
            this.dtpDOBinfo.Size = new System.Drawing.Size(200, 26);
            this.dtpDOBinfo.TabIndex = 42;
            // 
            // comboBox1G
            // 
            this.comboBox1G.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1G.FormattingEnabled = true;
            this.comboBox1G.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBox1G.Location = new System.Drawing.Point(744, 229);
            this.comboBox1G.Name = "comboBox1G";
            this.comboBox1G.Size = new System.Drawing.Size(121, 28);
            this.comboBox1G.TabIndex = 41;
            // 
            // comboBox1MStatus
            // 
            this.comboBox1MStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1MStatus.FormattingEnabled = true;
            this.comboBox1MStatus.Items.AddRange(new object[] {
            "Single",
            "Married",
            "Separated",
            "Divorce",
            "Widowed"});
            this.comboBox1MStatus.Location = new System.Drawing.Point(744, 182);
            this.comboBox1MStatus.Name = "comboBox1MStatus";
            this.comboBox1MStatus.Size = new System.Drawing.Size(121, 28);
            this.comboBox1MStatus.TabIndex = 40;
            // 
            // btnUpdateInfos
            // 
            this.btnUpdateInfos.BackColor = System.Drawing.Color.DarkBlue;
            this.btnUpdateInfos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateInfos.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdateInfos.Location = new System.Drawing.Point(190, 527);
            this.btnUpdateInfos.Name = "btnUpdateInfos";
            this.btnUpdateInfos.Size = new System.Drawing.Size(121, 44);
            this.btnUpdateInfos.TabIndex = 39;
            this.btnUpdateInfos.Text = "Update Info";
            this.btnUpdateInfos.UseVisualStyleBackColor = false;
            this.btnUpdateInfos.Click += new System.EventHandler(this.btnUpdateInfos_Click);
            // 
            // txtEmailInfo
            // 
            this.txtEmailInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailInfo.Location = new System.Drawing.Point(744, 370);
            this.txtEmailInfo.Multiline = true;
            this.txtEmailInfo.Name = "txtEmailInfo";
            this.txtEmailInfo.Size = new System.Drawing.Size(263, 40);
            this.txtEmailInfo.TabIndex = 38;
            // 
            // txtCNOInfo
            // 
            this.txtCNOInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCNOInfo.Location = new System.Drawing.Point(744, 309);
            this.txtCNOInfo.Multiline = true;
            this.txtCNOInfo.Name = "txtCNOInfo";
            this.txtCNOInfo.Size = new System.Drawing.Size(263, 40);
            this.txtCNOInfo.TabIndex = 37;
            // 
            // txtAddUInfo
            // 
            this.txtAddUInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddUInfo.Location = new System.Drawing.Point(211, 348);
            this.txtAddUInfo.Multiline = true;
            this.txtAddUInfo.Name = "txtAddUInfo";
            this.txtAddUInfo.Size = new System.Drawing.Size(358, 103);
            this.txtAddUInfo.TabIndex = 36;
            // 
            // txtLName
            // 
            this.txtLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLName.Location = new System.Drawing.Point(211, 240);
            this.txtLName.Multiline = true;
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(358, 40);
            this.txtLName.TabIndex = 35;
            // 
            // txtFirstname
            // 
            this.txtFirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstname.Location = new System.Drawing.Point(211, 182);
            this.txtFirstname.Multiline = true;
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.Size = new System.Drawing.Size(358, 40);
            this.txtFirstname.TabIndex = 34;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(618, 393);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(52, 20);
            this.lblEmail.TabIndex = 33;
            this.lblEmail.Text = "Email:";
            // 
            // lblContactNo
            // 
            this.lblContactNo.AutoSize = true;
            this.lblContactNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactNo.Location = new System.Drawing.Point(618, 328);
            this.lblContactNo.Name = "lblContactNo";
            this.lblContactNo.Size = new System.Drawing.Size(93, 20);
            this.lblContactNo.TabIndex = 32;
            this.lblContactNo.Text = "Contact No:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstName.Location = new System.Drawing.Point(102, 204);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(86, 20);
            this.lblFirstName.TabIndex = 26;
            this.lblFirstName.Text = "First Name";
            // 
            // lblAdd
            // 
            this.lblAdd.AutoSize = true;
            this.lblAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdd.Location = new System.Drawing.Point(102, 348);
            this.lblAdd.Name = "lblAdd";
            this.lblAdd.Size = new System.Drawing.Size(72, 20);
            this.lblAdd.TabIndex = 31;
            this.lblAdd.Text = "Address:";
            // 
            // lblICNumber
            // 
            this.lblICNumber.AutoSize = true;
            this.lblICNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblICNumber.Location = new System.Drawing.Point(99, 141);
            this.lblICNumber.Name = "lblICNumber";
            this.lblICNumber.Size = new System.Drawing.Size(89, 20);
            this.lblICNumber.TabIndex = 25;
            this.lblICNumber.Text = "IC Number:";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender.Location = new System.Drawing.Point(618, 237);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(67, 20);
            this.lblGender.TabIndex = 30;
            this.lblGender.Text = "Gender:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.Location = new System.Drawing.Point(102, 262);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(86, 20);
            this.lblLastName.TabIndex = 27;
            this.lblLastName.Text = "Last Name";
            // 
            // lblMaritalStatus
            // 
            this.lblMaritalStatus.AutoSize = true;
            this.lblMaritalStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaritalStatus.Location = new System.Drawing.Point(614, 183);
            this.lblMaritalStatus.Name = "lblMaritalStatus";
            this.lblMaritalStatus.Size = new System.Drawing.Size(111, 20);
            this.lblMaritalStatus.TabIndex = 29;
            this.lblMaritalStatus.Text = "Marital Status:";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOB.Location = new System.Drawing.Point(102, 311);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(103, 20);
            this.lblDOB.TabIndex = 28;
            this.lblDOB.Text = "Date of Birth:";
            // 
            // patient_info_create
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 713);
            this.Controls.Add(this.dtpDOBinfo);
            this.Controls.Add(this.comboBox1G);
            this.Controls.Add(this.comboBox1MStatus);
            this.Controls.Add(this.btnUpdateInfos);
            this.Controls.Add(this.txtEmailInfo);
            this.Controls.Add(this.txtCNOInfo);
            this.Controls.Add(this.txtAddUInfo);
            this.Controls.Add(this.txtLName);
            this.Controls.Add(this.txtFirstname);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblContactNo);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.lblAdd);
            this.Controls.Add(this.lblICNumber);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblMaritalStatus);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "patient_info_create";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "patient_info_create";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label HomepatientApp;
        private System.Windows.Forms.DateTimePicker dtpDOBinfo;
        private System.Windows.Forms.ComboBox comboBox1G;
        private System.Windows.Forms.ComboBox comboBox1MStatus;
        private System.Windows.Forms.Button btnUpdateInfos;
        private System.Windows.Forms.TextBox txtEmailInfo;
        private System.Windows.Forms.TextBox txtCNOInfo;
        private System.Windows.Forms.TextBox txtAddUInfo;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtFirstname;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblContactNo;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblAdd;
        private System.Windows.Forms.Label lblICNumber;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblMaritalStatus;
        private System.Windows.Forms.Label lblDOB;
    }
}