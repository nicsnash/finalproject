﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apppointment_Booking_System_2
{
    public partial class Patient_List : UserControl
    {
        public Patient_List()
        {
            InitializeComponent();
            LoadPatientData();
        }

        private void LoadPatientData()
        {
            try
            {
                // Establish connection to the database
                using (SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"))
                {
                    connect.Open();
                    string query = "SELECT * FROM datapatient";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connect);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Establish connection to the database
                using (SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"))
                {
                    connect.Open();
                    string query = "SELECT * FROM datapatient WHERE [Last Name] LIKE @lastName";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connect);
                    adapter.SelectCommand.Parameters.AddWithValue("@lastName", textBox1.Text + "%");
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void Patient_List_Load(object sender, EventArgs e)
        {
            LoadPatientData(); // Call the LoadPatientData method when the UserControl is loaded
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            // Clear placeholder text when textbox is clicked
            if (textBox1.Text == "Lastname")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black; // Set text color to black
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            // Restore placeholder text if textbox is left empty
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                textBox1.Text = "Lastname";
                textBox1.ForeColor = Color.Gray; // Set placeholder text color
            }
        }

        private void txtICnumber_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Establish connection to the database
                using (SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"))
                {
                    connect.Open();
                    string query = "SELECT * FROM datapatient WHERE [IC Number] LIKE @icNumber";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connect);
                    adapter.SelectCommand.Parameters.AddWithValue("@icNumber", txtICnumber.Text + "%");
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void txtICnumber_Enter(object sender, EventArgs e)
        {

            // Clear placeholder text when textbox is clicked
            if (txtICnumber.Text == "IC Number")
            {
                txtICnumber.Text = "";
                txtICnumber.ForeColor = Color.Black; // Set text color to black
            }
        }

        private void txtICnumber_Leave(object sender, EventArgs e)
        {
            // Restore placeholder text if textbox is left empty
            if (string.IsNullOrWhiteSpace(txtICnumber.Text))
            {
                txtICnumber.Text = "IC Number";
                txtICnumber.ForeColor = Color.Gray; // Set placeholder text color
            }
        }
    }
}
