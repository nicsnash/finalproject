﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Apppointment_Booking_System_2.adminDashboard;


namespace Apppointment_Booking_System_2
{
    public partial class Home : Form
    {
       
        public Home()
        {
            InitializeComponent();
            UpdateScheduleDisplay();
        }
        public void UpdateScheduleDisplay()
        {
            try
            {
                // Connect to the database
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"))
                {
                    // Open the connection
                    connection.Open();

                    // Define your SQL query to retrieve the latest schedule data
                    string query = "SELECT TOP 1 Day, Date, StartTime, EndTime, Availability FROM AdminSchedule ORDER BY ScheduleID DESC";

                    // Create a SqlCommand object to execute the query
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Create a DataTable to hold the results
                        DataTable scheduleData = new DataTable();

                        // Use a SqlDataAdapter to fill the DataTable
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(scheduleData);
                        }

                        // Check if scheduleData contains any rows
                        if (scheduleData.Rows.Count > 0)
                        {
                            // Build the schedule information string
                            StringBuilder scheduleInfo = new StringBuilder();

                            // Assuming the schedule data contains columns like Day, Date, StartTime, EndTime, and Availability
                            string day = scheduleData.Rows[0]["Day"].ToString();
                            string date = ((DateTime)scheduleData.Rows[0]["Date"]).ToString("MM/dd/yyyy");
                            TimeSpan startTime = (TimeSpan)scheduleData.Rows[0]["StartTime"];
                            TimeSpan endTime = (TimeSpan)scheduleData.Rows[0]["EndTime"];
                            string availability = scheduleData.Rows[0]["Availability"].ToString();

                            // Format time values in 12-hour clock format with AM/PM indicators
                            string startTimeString = DateTime.Today.Add(startTime).ToString("hh:mm tt");
                            string endTimeString = DateTime.Today.Add(endTime).ToString("hh:mm tt");

                            // Append the schedule information to the StringBuilder
                            scheduleInfo.AppendLine($"{"Day",-19}{"Date",-19}{"Start Time",-16}{"End Time",-14}{"Availability",-15}");
                            scheduleInfo.AppendLine($"{day,-17}{date,-15}{startTimeString,-15}{endTimeString,-15}{availability,-15}");

                            // Update the label text with the schedule information
                            UpdateScheduleLabel(scheduleInfo.ToString());
                        }
                        else
                        {
                            // If no schedule data is available, display a message
                            UpdateScheduleLabel("No schedule available.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions here
                MessageBox.Show("Error loading schedule data: " + ex.Message);
            }
        }




        public void DisplayNewSchedule(string day, DateTime date, TimeSpan startTime, TimeSpan endTime, string availability)
        {
            // Build the schedule information string for the new schedule
            string newScheduleInfo = $"Day: {day}, Date: {date:yyyy-MM-dd}, Time: {startTime:hh\\:mm} - {endTime:hh\\:mm}, Availability: {availability}";


            // Update the label text with the new schedule information
            lblOutput.Text = newScheduleInfo;
        }

      
        public void UpdateScheduleLabel(string scheduleInfo)
        {
            lblOutput.Text = scheduleInfo; // Update the label text
        }
        private void signupH_Click(object sender, EventArgs e)
        {
            signup sForm = new signup();
            sForm.Show();
            this.Hide();
        }

        private void loginH_Click(object sender, EventArgs e)
        {
            loginUser lForm = new loginUser();
            lForm.Show();
            this.Hide();
        }

        private void AdminH_Click(object sender, EventArgs e)
        {
            Form1 lForm = new Form1();
            lForm.Show();
            this.Hide();
        }
        
        private void lblOuput_Click(object sender, EventArgs e)
        {
            
            
        }

        private void btnBookNow_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

