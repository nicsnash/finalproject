﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Apppointment_Booking_System_2
{
    public partial class patientAppointment : Form
    {
        public patientAppointment()
        {
            InitializeComponent();
        }

        private void btnBookNow_Click(object sender, EventArgs e)
        {
           
                // If the user's profile information is not complete, redirect them to complete their profile
                patient_info_create infoForm = new patient_info_create("");

                infoForm.Show();
                this.Hide();
            
        }

   

        private void HomepatientApp_Click(object sender, EventArgs e)
        {
            Home lForm = new Home();
            lForm.Show();
            this.Hide();
        }

        private void lblpApp_Click(object sender, EventArgs e)
        {
            View_Appointment lForm = new View_Appointment();
            lForm.Show();
            this.Hide();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       
    }
}
