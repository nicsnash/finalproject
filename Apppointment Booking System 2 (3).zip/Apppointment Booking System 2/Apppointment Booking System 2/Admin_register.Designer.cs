﻿namespace Apppointment_Booking_System_2
{
    partial class Admin_register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.signupAdmin_password = new System.Windows.Forms.TextBox();
            this.signupAdmin_loginHere = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.signupAdmin_showPass = new System.Windows.Forms.CheckBox();
            this.signupAdmin_btn = new System.Windows.Forms.Button();
            this.signupAdmin_username = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.signupAdmin_email = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.HomeAdminR = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(68, 301);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 16);
            this.label9.TabIndex = 35;
            this.label9.Text = "Password:";
            // 
            // signupAdmin_password
            // 
            this.signupAdmin_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signupAdmin_password.Location = new System.Drawing.Point(71, 320);
            this.signupAdmin_password.Multiline = true;
            this.signupAdmin_password.Name = "signupAdmin_password";
            this.signupAdmin_password.PasswordChar = '*';
            this.signupAdmin_password.Size = new System.Drawing.Size(305, 30);
            this.signupAdmin_password.TabIndex = 34;
            // 
            // signupAdmin_loginHere
            // 
            this.signupAdmin_loginHere.AutoSize = true;
            this.signupAdmin_loginHere.Cursor = System.Windows.Forms.Cursors.Hand;
            this.signupAdmin_loginHere.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signupAdmin_loginHere.ForeColor = System.Drawing.Color.DimGray;
            this.signupAdmin_loginHere.Location = new System.Drawing.Point(249, 459);
            this.signupAdmin_loginHere.Name = "signupAdmin_loginHere";
            this.signupAdmin_loginHere.Size = new System.Drawing.Size(78, 15);
            this.signupAdmin_loginHere.TabIndex = 33;
            this.signupAdmin_loginHere.Text = "Login Here";
            this.signupAdmin_loginHere.Click += new System.EventHandler(this.signupAdmin_loginHere_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(100, 459);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(146, 15);
            this.label4.TabIndex = 32;
            this.label4.Text = "Already have an account?";
            // 
            // signupAdmin_showPass
            // 
            this.signupAdmin_showPass.AutoSize = true;
            this.signupAdmin_showPass.BackColor = System.Drawing.Color.Transparent;
            this.signupAdmin_showPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signupAdmin_showPass.ForeColor = System.Drawing.Color.Gray;
            this.signupAdmin_showPass.Location = new System.Drawing.Point(252, 358);
            this.signupAdmin_showPass.Name = "signupAdmin_showPass";
            this.signupAdmin_showPass.Size = new System.Drawing.Size(122, 20);
            this.signupAdmin_showPass.TabIndex = 31;
            this.signupAdmin_showPass.Text = "Show Password";
            this.signupAdmin_showPass.UseVisualStyleBackColor = false;
            this.signupAdmin_showPass.CheckedChanged += new System.EventHandler(this.signupAdmin_showPass_CheckedChanged);
            // 
            // signupAdmin_btn
            // 
            this.signupAdmin_btn.BackColor = System.Drawing.Color.MidnightBlue;
            this.signupAdmin_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.signupAdmin_btn.FlatAppearance.BorderSize = 0;
            this.signupAdmin_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signupAdmin_btn.ForeColor = System.Drawing.Color.White;
            this.signupAdmin_btn.Location = new System.Drawing.Point(70, 386);
            this.signupAdmin_btn.Name = "signupAdmin_btn";
            this.signupAdmin_btn.Size = new System.Drawing.Size(100, 35);
            this.signupAdmin_btn.TabIndex = 30;
            this.signupAdmin_btn.Text = "SIGNUP";
            this.signupAdmin_btn.UseVisualStyleBackColor = false;
            this.signupAdmin_btn.Click += new System.EventHandler(this.signupAdmin_btn_Click);
            // 
            // signupAdmin_username
            // 
            this.signupAdmin_username.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signupAdmin_username.Location = new System.Drawing.Point(70, 254);
            this.signupAdmin_username.Multiline = true;
            this.signupAdmin_username.Name = "signupAdmin_username";
            this.signupAdmin_username.Size = new System.Drawing.Size(305, 30);
            this.signupAdmin_username.TabIndex = 29;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(67, 235);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 28;
            this.label3.Text = "Username:";
            // 
            // signupAdmin_email
            // 
            this.signupAdmin_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signupAdmin_email.Location = new System.Drawing.Point(70, 192);
            this.signupAdmin_email.Multiline = true;
            this.signupAdmin_email.Name = "signupAdmin_email";
            this.signupAdmin_email.Size = new System.Drawing.Size(305, 30);
            this.signupAdmin_email.TabIndex = 27;
            this.signupAdmin_email.TextChanged += new System.EventHandler(this.signupAdmin_email_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(67, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 16);
            this.label2.TabIndex = 26;
            this.label2.Text = "Email Address:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(107, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 19);
            this.label1.TabIndex = 25;
            this.label1.Text = "Admin Register Account";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.signupAdmin_username);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.signupAdmin_password);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.signupAdmin_loginHere);
            this.panel1.Controls.Add(this.signupAdmin_email);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.signupAdmin_showPass);
            this.panel1.Controls.Add(this.signupAdmin_btn);
            this.panel1.Location = new System.Drawing.Point(277, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(428, 604);
            this.panel1.TabIndex = 36;
            // 
            // HomeAdminR
            // 
            this.HomeAdminR.AutoSize = true;
            this.HomeAdminR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.HomeAdminR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeAdminR.ForeColor = System.Drawing.Color.DimGray;
            this.HomeAdminR.Location = new System.Drawing.Point(61, 532);
            this.HomeAdminR.Name = "HomeAdminR";
            this.HomeAdminR.Size = new System.Drawing.Size(56, 20);
            this.HomeAdminR.TabIndex = 37;
            this.HomeAdminR.Text = "Home";
            this.HomeAdminR.Click += new System.EventHandler(this.HomeAdminR_Click);
            // 
            // Admin_register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(991, 603);
            this.Controls.Add(this.HomeAdminR);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Admin_register";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin_register";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox signupAdmin_password;
        private System.Windows.Forms.Label signupAdmin_loginHere;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox signupAdmin_showPass;
        private System.Windows.Forms.Button signupAdmin_btn;
        private System.Windows.Forms.TextBox signupAdmin_username;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox signupAdmin_email;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label HomeAdminR;
    }
}