﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Apppointment_Booking_System_2
{
    public partial class adminDashboard : UserControl
    {

        public adminDashboard()
        {
            InitializeComponent();        
            dataGridViewSchedule.CellClick += dataGridViewSchedule_CellContentClick;       
        }
 
        private void starttime_ValueChanged(object sender, EventArgs e)
        {
            txtStartTime.CustomFormat = "hh:mm:tt";
        }

        private void starttime_MouseDown(object sender, MouseEventArgs e)
        {
            txtStartTime.CustomFormat = "hh:mm:tt";
        }

        private void endtime_ValueChanged(object sender, EventArgs e)
        {
              txtEndtime.CustomFormat = "hh:mm:tt";
        }

        private void endtime_MouseDown(object sender, MouseEventArgs e)
        {
            txtEndtime.CustomFormat = "hh:mm:tt";
        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {
            // Check if txtAvailability is not null and if it has a selected item
            if (txtAvailability != null && txtAvailability.SelectedItem != null)
            {
                // Access the currently selected item in the DomainUpDown control
                string selectedItem = txtAvailability.SelectedItem.ToString();
            }


        }

        private void SubmitSched_Click(object sender, EventArgs e)
        {
            // Retrieve schedule information from the form controls
            string day = txtDay.Text;
            DateTime date = dateTimePicker1.Value.Date; // Use .Date to extract only the date part
            TimeSpan startTime = txtStartTime.Value.TimeOfDay;
            TimeSpan endTime = txtEndtime.Value.TimeOfDay;
            string availability = txtAvailability.Text;

            try
            {
                using (SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"))
                {
                    connect.Open();

                    // Check if the same record already exists
                    string checkQuery = "SELECT COUNT(*) FROM AdminSchedule WHERE Day = @Day AND Date = @Date AND StartTime = @StartTime AND EndTime = @EndTime AND Availability = @Availability";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, connect);
                    checkCmd.Parameters.AddWithValue("@Day", day);
                    checkCmd.Parameters.AddWithValue("@Date", date);
                    checkCmd.Parameters.AddWithValue("@StartTime", startTime);
                    checkCmd.Parameters.AddWithValue("@EndTime", endTime);
                    checkCmd.Parameters.AddWithValue("@Availability", availability);

                    int existingRecords = (int)checkCmd.ExecuteScalar();
                    if (existingRecords > 0)
                    {
                        MessageBox.Show("This schedule already exists.");
                    }
                    else
                    {
                        // If the record doesn't exist, proceed with insertion
                        string insertQuery = "INSERT INTO AdminSchedule (Day, Date, StartTime, EndTime, Availability) VALUES (@Day, @Date, @StartTime, @EndTime, @Availability); SELECT SCOPE_IDENTITY();";
                        SqlCommand cmd = new SqlCommand(insertQuery, connect);
                        cmd.Parameters.AddWithValue("@Day", day);
                        cmd.Parameters.AddWithValue("@Date", date);
                        cmd.Parameters.AddWithValue("@StartTime", startTime);
                        cmd.Parameters.AddWithValue("@EndTime", endTime);
                        cmd.Parameters.AddWithValue("@Availability", availability);

                        // Retrieve the ID of the newly added schedule
                        int newScheduleId = Convert.ToInt32(cmd.ExecuteScalar());

                        if (newScheduleId > 0)
                        {
                            MessageBox.Show("Schedule added successfully!");

                            // Pass the new schedule information to the Home form
                            Home homeForm = Application.OpenForms.OfType<Home>().FirstOrDefault();
                            if (homeForm != null)
                            {
                                homeForm.DisplayNewSchedule(day, date, startTime, endTime, availability);
                            }

                            LoadScheduleData(); // Reload all schedule data in the adminDashboard form
                        }
                        else
                        {
                            MessageBox.Show("Failed to add schedule!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }
        public void LoadScheduleData()
        {
            try
            {
                using (SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"))
                {
                    connect.Open();
                    string query = "SELECT ScheduleID, Day, Date, CONVERT(varchar(20), StartTime, 100) AS StartTime, CONVERT(varchar(20), EndTime, 100) AS EndTime, Availability FROM AdminSchedule"; // Include ScheduleID in the query
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connect);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridViewSchedule.DataSource = dataTable;

                    // Set visibility of ScheduleID column
                    dataGridViewSchedule.Columns["ScheduleID"].Visible = false; // Hide ScheduleID column

                    // Print column names to the console for debugging
                    foreach (DataGridViewColumn column in dataGridViewSchedule.Columns)
                    {
                        Console.WriteLine(column.Name);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading schedule data. Please try again later.");
            }
        }
    
        private void btnupdatesched_Click(object sender, EventArgs e)
        {
            // Check if a row is selected
            if (dataGridViewSchedule.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridViewSchedule.SelectedRows[0];

                // Retrieve the ID of the selected schedule
                int scheduleID = Convert.ToInt32(selectedRow.Cells["ScheduleID"].Value);

                // Retrieve the updated data from the input fields
                string day = txtDay.Text;
                DateTime date = dateTimePicker1.Value;
                TimeSpan startTime = txtStartTime.Value.TimeOfDay;
                TimeSpan endTime = txtEndtime.Value.TimeOfDay;
                string availability = txtAvailability.Text;

                try
                {
                    using (SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"))
                    {
                        connect.Open();
                        string query = "UPDATE AdminSchedule SET Day = @Day, Date = @Date, StartTime = @StartTime, EndTime = @EndTime, Availability = @Availability WHERE ScheduleID = @ScheduleID";
                        SqlCommand cmd = new SqlCommand(query, connect);
                        cmd.Parameters.AddWithValue("@Day", day);
                        cmd.Parameters.AddWithValue("@Date", date);
                        cmd.Parameters.AddWithValue("@StartTime", startTime);
                        cmd.Parameters.AddWithValue("@EndTime", endTime);
                        cmd.Parameters.AddWithValue("@Availability", availability);
                        cmd.Parameters.AddWithValue("@ScheduleID", scheduleID);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Schedule updated successfully!");
                            LoadScheduleData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to update schedule!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select a schedule to update.");
            }
        }
       


        private void dataGridViewSchedule_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0 && e.ColumnIndex >= 0) // Check if the cell clicked is not a column header
            {
                if (dataGridViewSchedule.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != DBNull.Value) // Check if the clicked cell is not DBNull
                {
                    // Proceed with populating input fields or any other actions
                    DataGridViewRow selectedRow = dataGridViewSchedule.Rows[e.RowIndex];
                    txtDay.Text = selectedRow.Cells["Day"].Value.ToString();

                    // Check if the Date cell value is DBNull before conversion
                    if (selectedRow.Cells["Date"].Value != DBNull.Value)
                    {
                        dateTimePicker1.Value = Convert.ToDateTime(selectedRow.Cells["Date"].Value);
                    }
                    else
                    {
                        dateTimePicker1.Value = DateTime.Today; // or set another default value
                    }

                    // Check if the StartTime cell value is DBNull before conversion
                    if (selectedRow.Cells["StartTime"].Value != DBNull.Value)
                    {
                        txtStartTime.Value = Convert.ToDateTime(selectedRow.Cells["StartTime"].Value);
                    }
                    else
                    {
                        txtStartTime.Value = DateTime.Now; // or set another default value
                    }

                    // Check if the EndTime cell value is DBNull before conversion
                    if (selectedRow.Cells["EndTime"].Value != DBNull.Value)
                    {
                        txtEndtime.Value = Convert.ToDateTime(selectedRow.Cells["EndTime"].Value);
                    }
                    else
                    {
                        txtEndtime.Value = DateTime.Now; // or set another default value
                    }

                    // Check if the Availability cell value is DBNull before conversion
                    if (selectedRow.Cells["Availability"].Value != DBNull.Value)
                    {
                        txtAvailability.Text = selectedRow.Cells["Availability"].Value.ToString();
                    }
                    else
                    {
                        txtAvailability.Text = ""; // or set another default value
                    }
                }
            }
        }


        private void btnDeleteSched_Click(object sender, EventArgs e)
        { // Check if any rows are selected
            if (dataGridViewSchedule.SelectedRows.Count > 0)
            {
                // Loop through all selected rows and delete them one by one
                foreach (DataGridViewRow selectedRow in dataGridViewSchedule.SelectedRows)
                {
                    // Retrieve the ID of the selected schedule
                    int scheduleID = Convert.ToInt32(selectedRow.Cells["ScheduleID"].Value);

                    try
                    {
                        using (SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"))
                        {
                            connect.Open();
                            string query = "DELETE FROM AdminSchedule WHERE ScheduleID = @ScheduleID";
                            SqlCommand cmd = new SqlCommand(query, connect);
                            cmd.Parameters.AddWithValue("@ScheduleID", scheduleID);

                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                // Successful deletion message for each row
                                MessageBox.Show("Schedule deleted successfully!");
                                LoadScheduleData();
                            }
                            else
                            {
                                // Show failed deletion message if no rows were affected
                                MessageBox.Show("Failed to delete schedule!");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }

                // Clear the selection after deleting all selected rows
                dataGridViewSchedule.ClearSelection();
            }
            else
            {
                MessageBox.Show("Please select schedule(s) to delete.");
            }
        }

        private void btnClearSched_Click(object sender, EventArgs e)
        {
            // Clear all input fields
            txtDay.Text = "";
            dateTimePicker1.Value = DateTime.Today;
            txtStartTime.Value = DateTime.Now;
            txtEndtime.Value = DateTime.Now;
            txtAvailability.Text = "";
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
          
        }

       
    }
    }


       
    

