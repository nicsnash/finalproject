﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;
using System.Text.RegularExpressions;

namespace Apppointment_Booking_System_2
{
    public partial class signup : Form
    {
        
        public signup()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True");
        private void signup_loginHere_Click(object sender, EventArgs e)
        {
            loginUser lForm = new loginUser();
            lForm.Show();
            this.Hide();
        }

        private void signup_btn_Click(object sender, EventArgs e)
        {
            string email = signup_email.Text.Trim();
            string username = signup_username.Text.Trim();
            string password = signup_password.Text.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Invalid email format. Please enter a valid email address.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                conn.Open();

                string checkUsernameQuery = "SELECT * FROM signup_data WHERE username = @username";
                using (SqlCommand checkUserCmd = new SqlCommand(checkUsernameQuery, conn))
                {
                    checkUserCmd.Parameters.AddWithValue("@username", username);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(checkUserCmd))
                    {
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        if (table.Rows.Count >= 1)
                        {
                            MessageBox.Show(username + " is already taken. Please choose a different username.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }

                string insertDataQuery = "INSERT INTO signup_data (email, username, password) VALUES (@email, @username, @password)";
                using (SqlCommand cmd = new SqlCommand(insertDataQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Registered successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // TO SWITCH THE FORM 
                    Home lForm = new Home();
                    lForm.Show();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conn.Close();
            }
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                // Regular expression pattern for validating email addresses
                string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
                return Regex.IsMatch(email, pattern);
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        private void signup_email_TextChanged(object sender, EventArgs e)
        {

        }

        private void HomeSignupUser_Click(object sender, EventArgs e)
        {
            Home lForm = new Home();
            lForm.Show();
            this.Hide();
        }

        private void signup_showPass_CheckedChanged(object sender, EventArgs e)
        {
            // Check if the show password checkbox is checked
            if (signup_showPass.Checked)
            {
                // If checked, show the password characters
                signup_password.UseSystemPasswordChar = true;
            }
            else
            {
                // If not checked, hide the password characters
                signup_password.UseSystemPasswordChar = false;
            }
        }
    }
        }

                        
                    
  