﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apppointment_Booking_System_2
{
    public partial class Admin_register : Form
    {
        public Admin_register()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True");
        private void signupAdmin_btn_Click(object sender, EventArgs e)
        {
            string username = signupAdmin_username.Text.Trim();
            string email = signupAdmin_email.Text.Trim();
            string password = signupAdmin_password.Text.Trim();

            // Validate input fields
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Insert admin data into the database
            try
            {
                conn.Open();
                string insertQuery = "INSERT INTO AdminData (username, email, password) VALUES (@username, @email, @password)";
                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Admin registered successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conn.Close();
            }
        }
        private void signupAdmin_loginHere_Click(object sender, EventArgs e)
        {
            Form1 lForm = new Form1();
            lForm.Show();
            this.Hide();
        }

        private void login_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void signupAdmin_email_TextChanged(object sender, EventArgs e)
        {

        }

        private void HomeAdminR_Click(object sender, EventArgs e)
        {
            Home lForm = new Home();
            lForm.Show();
            this.Hide();
        }

        private void signupAdmin_showPass_CheckedChanged(object sender, EventArgs e)
        {
            // Check if the show password checkbox is checked
            if (signupAdmin_showPass.Checked)
            {
                // If checked, show the password characters
                signupAdmin_password.UseSystemPasswordChar = true;
            }
            else
            {
                // If not checked, hide the password characters
                signupAdmin_password.UseSystemPasswordChar = false;
            }
        }

    }
}
