﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apppointment_Booking_System_2
{
    public partial class dashbord1 : UserControl
    {
        public void AddPatientInfoToGrid(string[] patientInfo)
        {
            dataGridView1.Rows.Add(patientInfo);
        }
        public dashbord1()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dashbord1_Load(object sender, EventArgs e)
        {

        }
    }
}
