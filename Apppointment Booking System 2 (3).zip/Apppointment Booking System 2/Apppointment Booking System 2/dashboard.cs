﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apppointment_Booking_System_2
{
    public partial class dashboard : Form
    {
        private UserControl currentControl;
        public dashboard()
        {
            InitializeComponent();
        }
        private void ShowControl(UserControl control)
        {
            panel3.Controls.Clear();
            control.Dock = DockStyle.Fill;
            panel3.Controls.Add(control);
            currentControl = control;
        }

        private void LoadPatientapp()
        {
            dashbord1 patientapp = new dashbord1();
            ShowControl(patientapp);
        }
        private void LoadPatientData()
        {
            Patient_List patient_List = new Patient_List();
            ShowControl(patient_List);
        }

        private void LoadScheduleData()
        {
            adminDashboard adminDashboard = new adminDashboard();
            ShowControl(adminDashboard);
            adminDashboard.LoadScheduleData(); // Load the schedule data into the DataGridView
        }
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            dashbord1 patientapp = new dashbord1();
            ShowControl(patientapp);
            LoadPatientapp();

        }

        private void btnPatientL_Click(object sender, EventArgs e)
        {
            Patient_List patient_List = new Patient_List();
            ShowControl(patient_List);
            LoadPatientData();
        }

        private void btnAddp_Click(object sender, EventArgs e)
        {
            Add_Patient add_Patient = new Add_Patient();
            ShowControl(add_Patient);

            // Load patient data into the Add_Patient form
            add_Patient.LoadPatientData();

        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            adminDashboard adminDashboard = new adminDashboard();
            ShowControl(adminDashboard);

            // Load the schedule data into the DataGridView
            adminDashboard.LoadScheduleData();
        }

        private void logoutDashboard_Click(object sender, EventArgs e)
        {
            // Close the current dashboard form
            this.Close();

            // Assuming LoginForm is the name of your login form
            loginUser loginUser = new loginUser();
            loginUser.Show(); // Show the login form
        }

      
    }
}
    

