﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static Apppointment_Booking_System_2.Book_Appointment;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Apppointment_Booking_System_2
{
    public partial class patient_info_create : Form
    {
        private string userEmail;

        public patient_info_create(string userEmail)
        {
            InitializeComponent();
            this.userEmail = userEmail; // Set the userEmail field
            PopulateUserInfo(); // Populate user information using the userEmail
        }
        private void PopulateUserInfo()
        {
            try
            {
                string connectionString = "Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM datapatient WHERE [Email] = @userEmail";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userEmail", userEmail);
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            txtFirstname.Text = reader["First Name"].ToString();
                            txtLName.Text = reader["Last Name"].ToString();
                            dtpDOBinfo.Value = Convert.ToDateTime(reader["Date of Birth"]);
                            comboBox1MStatus.Text = reader["Marital Status"].ToString();
                            comboBox1G.Text = reader["Gender"].ToString();
                            txtAddUInfo.Text = reader["Address"].ToString();
                            txtCNOInfo.Text = reader["Contact No"].ToString();
                            txtEmailInfo.Text = userEmail;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private string GetAdminScheduleInfo()
        {
            string connectionString = "Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True"; // Replace with your actual connection string
            string query = "SELECT TOP 1 Day, Date, StartTime, EndTime FROM AdminSchedule ORDER BY Date DESC"; // Assuming you only need the latest schedule

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            string day = reader["Day"].ToString();
                            string date = Convert.ToDateTime(reader["Date"]).ToString("dd/MM/yyyy");
                            string startTime = reader["StartTime"].ToString();
                            string endTime = reader["EndTime"].ToString();

                            return $"Day: {day}\nDate: {date}\nTime: {startTime} - {endTime}";
                        }
                        else
                        {
                            return "No schedule found.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching schedule: " + ex.Message);
                return "Error fetching schedule.";
            }
        }

        private void SaveUserInfoToFile(string userInfo)
        {
            // Save user information to a file
            File.WriteAllText("userInfo.txt", userInfo);
        }
        private string GenerateICNumber()
        {
            // You can implement your logic here to generate the IC Number
            // For simplicity, let's assume it's a random 5-digit number
            Random rnd = new Random();
            return "IC" + rnd.Next(10000, 99999).ToString();
        }
        private void btnUpdateInfos_Click(object sender, EventArgs e)
        {
            try
            {
                // Retrieve values from the input fields
                string name = txtFirstname.Text;
                string lastName = txtLName.Text;
                DateTime dob = dtpDOBinfo.Value;
                string contact = txtCNOInfo.Text;
                string maritalStatus = comboBox1MStatus.Text;
                string gender = comboBox1G.Text;
                string address = txtAddUInfo.Text;
                string email = txtEmailInfo.Text;



                // Generate IC Number
                string icNumber = GenerateICNumber(); // Generate IC Number

                // Check if any required field is empty
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(contact) || string.IsNullOrEmpty(address) || string.IsNullOrEmpty(email))
                {
                    MessageBox.Show("Please complete all the required information.", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Exit the method
                }

                // Validate contact number
                if (!contact.StartsWith("09") || contact.Length != 11 || !contact.Skip(2).All(char.IsDigit))
                {
                    MessageBox.Show("Please enter a valid mobile number starting with '09' and with 11 digits.", "Invalid Contact Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Exit the method
                }

                // Validate email address
                if (!email.EndsWith("@gmail.com"))
                {
                    MessageBox.Show("Please enter a valid Gmail address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Exit the method
                }

                // Check if marital status is selected
                if (string.IsNullOrEmpty(maritalStatus))
                {
                    MessageBox.Show("Please select your marital status.", "Marital Status Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Exit the method
                }

                // Check if gender is selected
                if (string.IsNullOrEmpty(gender))
                {
                    MessageBox.Show("Please select your gender.", "Gender Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Exit the method
                }

                // Concatenate the information into one string
                string userInfo = $"IC Number: {icNumber}\n" +
                                  $"First Name: {name}\n" +
                                  $"Last Name: {lastName}\n" +
                                  $"Date of Birth: {dob.ToString("yyyy-MM-dd")}\n" +
                                  $"Marital Status: {maritalStatus}\n" +
                                  $"Gender: {gender}\n" +
                                  $"Address: {address}\n" +
                                  $"Contact No: {contact}\n" +
                                  $"Email: {email}";


                // Prompt for confirmation before updating
                DialogResult result = MessageBox.Show("Are you sure you want to update the information?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    // Choose the approach to persist the data (file-based or database-based)
                    bool useDatabase = true; // Set to true to use database, false to use file

                    if (useDatabase)
                    {
                        // Save user info to database
                        SaveUserInfoToDatabase(icNumber, name, lastName, dob, contact, maritalStatus, gender, address, email);

                    }
                    else
                    {
                        // Save user information to file
                        SaveUserInfoToFile(userInfo);
                    }

                    // Pass the existing instance of Update_Profile_Info form to the Book_Appointment form
                    Book_Appointment appointmentForm = new Book_Appointment(this);

                    // Set the user information and schedule information
                    appointmentForm.SetUserInformation(userInfo);

                    // Show the Book_Appointment form
                    appointmentForm.Show();

                    // Hide the Update_Profile_Info form
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }



        private void SaveUserInfoToDatabase(string icNumber, string name, string lastName, DateTime dob, string contact, string maritalStatus, string gender, string address, string email)
        {
            // Connection string for your database
            string connectionString = "Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = @"INSERT INTO datapatient ([IC Number], [First Name], [Last Name], [Date of Birth], [Contact No], [Marital Status], [Gender], [Address], [Email]) 
                         VALUES (@ICNumber, @FirstName, @LastName, @DOB, @ContactNo, @MaritalStatus, @Gender, @Address, @Email)";

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@ICNumber", icNumber);
                cmd.Parameters.AddWithValue("@FirstName", name);
                cmd.Parameters.AddWithValue("@LastName", lastName);
                cmd.Parameters.AddWithValue("@DOB", dob);
                cmd.Parameters.AddWithValue("@ContactNo", contact);
                cmd.Parameters.AddWithValue("@MaritalStatus", maritalStatus);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@Email", email);

                cmd.ExecuteNonQuery();
            }
        }


    }
}


