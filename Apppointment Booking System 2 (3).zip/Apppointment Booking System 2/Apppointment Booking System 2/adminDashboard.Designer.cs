﻿namespace Apppointment_Booking_System_2
{
    partial class adminDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnClearSched = new System.Windows.Forms.Button();
            this.btnDeleteSched = new System.Windows.Forms.Button();
            this.btnupdatesched = new System.Windows.Forms.Button();
            this.SubmitSched = new System.Windows.Forms.Button();
            this.txtAvailability = new System.Windows.Forms.DomainUpDown();
            this.txtEndtime = new System.Windows.Forms.DateTimePicker();
            this.txtStartTime = new System.Windows.Forms.DateTimePicker();
            this.txtDay = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblDay = new System.Windows.Forms.Label();
            this.lblStartTime = new System.Windows.Forms.Label();
            this.lblEndTime = new System.Windows.Forms.Label();
            this.lblAvailability = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.dataGridViewSchedule = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchedule)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(7, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "Add Schedule";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(59)))), ((int)(((byte)(112)))));
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(29, 87);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(945, 31);
            this.panel1.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.btnClearSched);
            this.panel2.Controls.Add(this.btnDeleteSched);
            this.panel2.Controls.Add(this.btnupdatesched);
            this.panel2.Controls.Add(this.SubmitSched);
            this.panel2.Controls.Add(this.txtAvailability);
            this.panel2.Controls.Add(this.txtEndtime);
            this.panel2.Controls.Add(this.txtStartTime);
            this.panel2.Controls.Add(this.txtDay);
            this.panel2.Controls.Add(this.dateTimePicker1);
            this.panel2.Controls.Add(this.lblDay);
            this.panel2.Controls.Add(this.lblStartTime);
            this.panel2.Controls.Add(this.lblEndTime);
            this.panel2.Controls.Add(this.lblAvailability);
            this.panel2.Controls.Add(this.lblDate);
            this.panel2.Location = new System.Drawing.Point(29, 115);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(945, 181);
            this.panel2.TabIndex = 13;
            // 
            // btnClearSched
            // 
            this.btnClearSched.BackColor = System.Drawing.Color.DarkBlue;
            this.btnClearSched.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearSched.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClearSched.Location = new System.Drawing.Point(821, 140);
            this.btnClearSched.Name = "btnClearSched";
            this.btnClearSched.Size = new System.Drawing.Size(110, 38);
            this.btnClearSched.TabIndex = 15;
            this.btnClearSched.Text = "Clear";
            this.btnClearSched.UseVisualStyleBackColor = false;
            this.btnClearSched.Click += new System.EventHandler(this.btnClearSched_Click);
            // 
            // btnDeleteSched
            // 
            this.btnDeleteSched.BackColor = System.Drawing.Color.DarkBlue;
            this.btnDeleteSched.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteSched.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDeleteSched.Location = new System.Drawing.Point(705, 140);
            this.btnDeleteSched.Name = "btnDeleteSched";
            this.btnDeleteSched.Size = new System.Drawing.Size(110, 38);
            this.btnDeleteSched.TabIndex = 15;
            this.btnDeleteSched.Text = "Delete";
            this.btnDeleteSched.UseVisualStyleBackColor = false;
            this.btnDeleteSched.Click += new System.EventHandler(this.btnDeleteSched_Click);
            // 
            // btnupdatesched
            // 
            this.btnupdatesched.BackColor = System.Drawing.Color.DarkBlue;
            this.btnupdatesched.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatesched.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnupdatesched.Location = new System.Drawing.Point(589, 140);
            this.btnupdatesched.Name = "btnupdatesched";
            this.btnupdatesched.Size = new System.Drawing.Size(110, 38);
            this.btnupdatesched.TabIndex = 12;
            this.btnupdatesched.Text = "Update";
            this.btnupdatesched.UseVisualStyleBackColor = false;
            this.btnupdatesched.Click += new System.EventHandler(this.btnupdatesched_Click);
            // 
            // SubmitSched
            // 
            this.SubmitSched.BackColor = System.Drawing.Color.DarkBlue;
            this.SubmitSched.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitSched.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SubmitSched.Location = new System.Drawing.Point(87, 140);
            this.SubmitSched.Name = "SubmitSched";
            this.SubmitSched.Size = new System.Drawing.Size(110, 38);
            this.SubmitSched.TabIndex = 10;
            this.SubmitSched.Text = "Submit";
            this.SubmitSched.UseVisualStyleBackColor = false;
            this.SubmitSched.Click += new System.EventHandler(this.SubmitSched_Click);
            // 
            // txtAvailability
            // 
            this.txtAvailability.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAvailability.Items.Add("Available");
            this.txtAvailability.Items.Add("Not Available");
            this.txtAvailability.Location = new System.Drawing.Point(157, 100);
            this.txtAvailability.Name = "txtAvailability";
            this.txtAvailability.Size = new System.Drawing.Size(199, 26);
            this.txtAvailability.TabIndex = 9;
            this.txtAvailability.SelectedItemChanged += new System.EventHandler(this.domainUpDown1_SelectedItemChanged);
            // 
            // txtEndtime
            // 
            this.txtEndtime.CustomFormat = " ";
            this.txtEndtime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEndtime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtEndtime.Location = new System.Drawing.Point(666, 51);
            this.txtEndtime.Name = "txtEndtime";
            this.txtEndtime.ShowUpDown = true;
            this.txtEndtime.Size = new System.Drawing.Size(200, 26);
            this.txtEndtime.TabIndex = 8;
            this.txtEndtime.ValueChanged += new System.EventHandler(this.endtime_ValueChanged);
            this.txtEndtime.MouseDown += new System.Windows.Forms.MouseEventHandler(this.endtime_MouseDown);
            // 
            // txtStartTime
            // 
            this.txtStartTime.CustomFormat = "  ";
            this.txtStartTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtStartTime.Location = new System.Drawing.Point(666, 7);
            this.txtStartTime.Name = "txtStartTime";
            this.txtStartTime.ShowUpDown = true;
            this.txtStartTime.Size = new System.Drawing.Size(200, 26);
            this.txtStartTime.TabIndex = 7;
            this.txtStartTime.ValueChanged += new System.EventHandler(this.starttime_ValueChanged);
            this.txtStartTime.MouseDown += new System.Windows.Forms.MouseEventHandler(this.starttime_MouseDown);
            // 
            // txtDay
            // 
            this.txtDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDay.Location = new System.Drawing.Point(156, 53);
            this.txtDay.Name = "txtDay";
            this.txtDay.Size = new System.Drawing.Size(200, 26);
            this.txtDay.TabIndex = 6;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(156, 9);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 26);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // lblDay
            // 
            this.lblDay.AutoSize = true;
            this.lblDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDay.Location = new System.Drawing.Point(47, 59);
            this.lblDay.Name = "lblDay";
            this.lblDay.Size = new System.Drawing.Size(41, 20);
            this.lblDay.TabIndex = 4;
            this.lblDay.Text = "Day:";
            // 
            // lblStartTime
            // 
            this.lblStartTime.AutoSize = true;
            this.lblStartTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartTime.Location = new System.Drawing.Point(557, 13);
            this.lblStartTime.Name = "lblStartTime";
            this.lblStartTime.Size = new System.Drawing.Size(86, 20);
            this.lblStartTime.TabIndex = 3;
            this.lblStartTime.Text = "Start Time:";
            // 
            // lblEndTime
            // 
            this.lblEndTime.AutoSize = true;
            this.lblEndTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndTime.Location = new System.Drawing.Point(557, 60);
            this.lblEndTime.Name = "lblEndTime";
            this.lblEndTime.Size = new System.Drawing.Size(76, 20);
            this.lblEndTime.TabIndex = 2;
            this.lblEndTime.Text = "End Time";
            // 
            // lblAvailability
            // 
            this.lblAvailability.AutoSize = true;
            this.lblAvailability.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvailability.Location = new System.Drawing.Point(47, 100);
            this.lblAvailability.Name = "lblAvailability";
            this.lblAvailability.Size = new System.Drawing.Size(85, 20);
            this.lblAvailability.TabIndex = 1;
            this.lblAvailability.Text = "Availability:";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(47, 16);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(48, 20);
            this.lblDate.TabIndex = 0;
            this.lblDate.Text = "Date:";
            // 
            // dataGridViewSchedule
            // 
            this.dataGridViewSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSchedule.Location = new System.Drawing.Point(29, 346);
            this.dataGridViewSchedule.Name = "dataGridViewSchedule";
            this.dataGridViewSchedule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSchedule.Size = new System.Drawing.Size(945, 226);
            this.dataGridViewSchedule.TabIndex = 14;
            this.dataGridViewSchedule.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSchedule_CellContentClick);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(59)))), ((int)(((byte)(112)))));
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(29, 319);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(945, 31);
            this.panel3.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(7, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "List of Schedule";
            // 
            // adminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.dataGridViewSchedule);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "adminDashboard";
            this.Size = new System.Drawing.Size(1003, 605);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchedule)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblDay;
        private System.Windows.Forms.Label lblStartTime;
        private System.Windows.Forms.Label lblEndTime;
        private System.Windows.Forms.Label lblAvailability;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.TextBox txtDay;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker txtEndtime;
        private System.Windows.Forms.DateTimePicker txtStartTime;
        private System.Windows.Forms.DomainUpDown txtAvailability;
        private System.Windows.Forms.Button SubmitSched;
        private System.Windows.Forms.DataGridView dataGridViewSchedule;
        private System.Windows.Forms.Button btnupdatesched;
        private System.Windows.Forms.Button btnDeleteSched;
        private System.Windows.Forms.Button btnClearSched;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
    }
}
