﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;

namespace Apppointment_Booking_System_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            login_showPass.CheckedChanged += login_showPass_CheckedChanged;
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-HF1153L;Initial Catalog=loginData;Integrated Security=True");
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void login_btn_Click(object sender, EventArgs e)
        {

            if (login_username.Text == "" || login_password.Text == "")
            {
                MessageBox.Show("Please fil all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (conn.State != ConnectionState.Open)
                {
                    try
                    {
                        conn.Open();

                        String selectData = "SELECT * FROM AdminData WHERE username = @username AND password = @password";
                        using (SqlCommand cmd = new SqlCommand(selectData, conn))
                        {
                            cmd.Parameters.AddWithValue("@username", login_username.Text);
                            cmd.Parameters.AddWithValue("@password", login_password.Text);
                            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                            DataTable table = new DataTable();
                            adapter.Fill(table);

                            if (table.Rows.Count >= 1)
                            {
                                MessageBox.Show("Logged In successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                dashboard dForm = new dashboard();
                                dForm.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Incorrect Username/Password", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error Connecting: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }

        }

        private void login_registerHere_Click(object sender, EventArgs e)
        {

           Admin_register aForm = new Admin_register();
            aForm.Show();
            this.Hide();
        }

        private void login_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void login_username_TextChanged(object sender, EventArgs e)
        {

        }

        private void login_showPass_CheckedChanged(object sender, EventArgs e)
        {

            if (login_showPass.Checked)
            {
                // If the "Show Password" checkbox is checked, display the plain-text password
                login_password.UseSystemPasswordChar = true;
            }
            else
            {
                // If the "Show Password" checkbox is unchecked, hide the password with asterisks
                login_password.UseSystemPasswordChar = false;
            }
        }

        private void AdminRegister_Click(object sender, EventArgs e)
        {
            Admin_register aForm = new Admin_register();
            aForm.Show();
            this.Hide();
        }

        private void HomeAdminLogin_Click(object sender, EventArgs e)
        {
            Home lForm = new Home();
            lForm.Show();
            this.Hide();
        }
    }
}
